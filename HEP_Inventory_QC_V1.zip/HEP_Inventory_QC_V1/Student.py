#--------------------------------------------------------------------------------------------
#
#       Student Class for CSU HEP Lab Inventory System, holds student employee info
#
#                     created by: Ross Stauder and Nikola Durand
#                                   rev: July 2022
#                     DUNE - Deep Underground Neutrino Experiment
#--------------------------------------------------------------------------------------------

class Student:
    student_info = [
        ('833068328', 'Ross Stauder'),
        ('836163315', 'Melissa Sturdivant'),
        ('829124941', 'Christian Norris'),
        ('832879426', 'Kade Pait'),
        ('831102644', 'Sean Coleman'),
        ('832389888', 'Nikki Rehberg'),
        ('832960857', 'Tabor Horrigan'),
        ('833168358', 'Ben Morrison'),
        ('831331306', 'Nikola Durand'),
        ('832428017', 'Issac Reeves'),
    ]

    def __init__(self, csuid):
        self.csuid = csuid
        for item in Student.student_info:
            if item[0] == self.csuid:
                self.name = item[1]
