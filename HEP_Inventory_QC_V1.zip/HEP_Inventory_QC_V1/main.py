#--------------------------------------------------------------------------------------------
#
#   Main program for CSU HEP Lab Inventory System, controls all data flow
#
#                       created by: Ross Stauder
#                           rev: July 2022
#             DUNE - Deep Underground Neutrino Experiment
#--------------------------------------------------------------------------------------------

from Cable import Cable
from Item import Item
from Student import Student
from converter import convert
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import filecmp
import gui
import os
import sys

args = sys.argv[1:]
print(args)

#-------DATABASE SETUP-------#

#retrieve admin credentials
cred = credentials.Certificate('hep-test-eef24-firebase-adminsdk-8mx4y-5b2db3c614.json')

# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://hep-test-eef24-default-rtdb.firebaseio.com/'
})

# As an admin, the app has access to read and write all data
ref = db.reference('')

#----------------------------#

#for testing purposes
#barcode1 = '340150000000'
#barcode2 = '400001110041'
#item = Item(barcode2)

#for testing purposes
#testCable = Cable(barcode1)
#testItem = Item(barcode2)

# If the barcode sheet has been updated, update the .txt file used for the javascript front-end
tempFile = convert('Barcode_Sheet_FINAL.csv', 'temp_file.txt')
if(not filecmp.cmp('temp_file.txt', 'barcode.txt')):
    convert('Barcode_Sheet_FINAL.csv', 'barcode.txt')
os.remove('temp_file.txt')

# -------GUI CONTROL FLOW------- #
if(not len(args) > 0):
    #load first page of gui, asks for an ID to be scanned
    csuid = gui.begin()
    #create a student object from the csuid
    student = Student(csuid)
    #find the students name
    username = student.name
else:
    student = Student(args[-1])
    csuid = student.csuid
    username = student.name
#main loop
while True:
    #load second page of gui, asks for an item to be scanned
    barcode = gui.scanItem(username)
    obj = None #initialize an object

    #detect whether the barcode refers to a Cable or Mechanical Item
    if int(barcode[0]) < 4:
        #cable
        obj = Cable(int(barcode)) #create object
        op = gui.addCableQC(obj) #display the cable QC form on the GUI
        obj.postToDB(op, username, ref) #call the post to DB method of the cable class
        sys.argv.append(csuid)
        os.execl(sys.executable, sys.executable, *sys.argv) #restarts the current program
    else:
        #mechanical item
        obj = Item(barcode) #create object
        qty = gui.addQuantity(obj) #display the inventory update screen on the GUI
        obj.postToDB(qty, ref) #call the post to DB method of the Item class
        sys.argv.append(csuid)
        os.execl(sys.executable, sys.executable, *sys.argv) #restarts the current program

gui.root.mainloop()




